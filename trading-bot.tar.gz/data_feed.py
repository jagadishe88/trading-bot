import aiohttp
import asyncio
import datetime
import json
import os
import sys
import math
from utils import get_secret

# Load Alpaca credentials using the same system as alert_engine.py
ALPACA_KEY = get_secret("APCA_API_KEY_ID")
ALPACA_SECRET = get_secret("APCA_API_SECRET_KEY")

HEADERS = {
    "APCA-API-KEY-ID": ALPACA_KEY,
    "APCA-API-SECRET-KEY": ALPACA_SECRET
}

# Multiple base URLs to try
PAPER_BASE_URL = "https://paper-api.alpaca.markets"
LIVE_BASE_URL = "https://api.alpaca.markets"
DATA_BASE_URL = "https://data.alpaca.markets"

# Stock data endpoints
QUOTE_URL = f"{DATA_BASE_URL}/v2/stocks/{{symbol}}/quotes/latest"
BARS_URL = f"{DATA_BASE_URL}/v2/stocks/{{symbol}}/bars"

# Options endpoints to try
OPTION_CHAIN_URLS = [
    f"{DATA_BASE_URL}/v1beta1/options/contracts?underlying_symbols={{symbol}}",
    f"{PAPER_BASE_URL}/v2/options/contracts?underlying_symbol={{symbol}}",
    f"{LIVE_BASE_URL}/v2/options/contracts?underlying_symbol={{symbol}}"
]

OPTION_QUOTES_URL = f"{DATA_BASE_URL}/v1beta1/options/quotes/latest"

async def fetch_json(session, url, params=None):
    try:
        async with session.get(url, headers=HEADERS, params=params) as response:
            if response.status == 200:
                return await response.json()
            else:
                print(f"❌ API Error {response.status} for URL: {url}")
                if response.status == 401:
                    print("   🔑 This suggests missing permissions for this endpoint")
                try:
                    error_text = await response.text()
                    print(f"   Error details: {error_text}")
                except:
                    pass
                return None
    except Exception as e:
        print(f"❌ Request failed for {url}: {e}")
        return None

async def fetch_stock_quote(symbol, session):
    """Fetch current stock quote"""
    url = QUOTE_URL.format(symbol=symbol)
    data = await fetch_json(session, url, params={"feed": "iex"})
    if not data or "quote" not in data:
        return None
    
    quote = data["quote"]
    return {
        "symbol": symbol,
        "ask_price": quote.get("ap"),
        "bid_price": quote.get("bp"),
        "last_price": quote.get("ap", quote.get("bp")),  # Use ask as fallback
        "timestamp": quote.get("t")
    }

async def fetch_stock_bars(symbol, session, timeframe="1Day", limit=10):
    """Fetch historical stock bars for volatility calculation"""
    url = BARS_URL.format(symbol=symbol)
    params = {
        "timeframe": timeframe,
        "limit": limit,
        "asof": datetime.datetime.now().isoformat(),
        "feed": "iex"
    }
    
    data = await fetch_json(session, url, params=params)
    if not data or "bars" not in data:
        print(f"⚠️ No bars data available for {symbol}")
        return []
    
    return data["bars"]

async def fetch_option_chain(symbol, session):
    """Try multiple endpoints to fetch options data"""
    print(f"🔍 Attempting to fetch option chain for {symbol}...")
    
    for i, url_template in enumerate(OPTION_CHAIN_URLS):
        url = url_template.format(symbol=symbol)
        print(f"  📡 Trying endpoint {i+1}: {url.split('?')[0]}...")
        
        data = await fetch_json(session, url)
        if data:
            contracts = None
            if "option_contracts" in data:
                contracts = data["option_contracts"]
            elif "contracts" in data:
                contracts = data["contracts"]
            elif isinstance(data, list):
                contracts = data
            
            if contracts and len(contracts) > 0:
                print(f"  ✅ Success! Found {len(contracts)} contracts")
                return contracts
        
        print(f"  ❌ Endpoint {i+1} failed")
    
    print("❌ All options endpoints failed - likely missing options permissions")
    return []

def calculate_implied_volatility_estimate(bars):
    """Calculate a rough IV estimate from historical volatility"""
    if len(bars) < 2:
        return 0.25  # Default 25% if no data
    
    returns = []
    for i in range(1, len(bars)):
        prev_close = bars[i-1].get('c', 0)
        curr_close = bars[i].get('c', 0)
        if prev_close > 0 and curr_close > 0:
            returns.append(math.log(curr_close / prev_close))
    
    if not returns:
        return 0.25
    
    # Calculate standard deviation and annualize (roughly)
    mean_return = sum(returns) / len(returns)
    variance = sum((r - mean_return) ** 2 for r in returns) / len(returns)
    daily_vol = math.sqrt(variance)
    annual_vol = daily_vol * math.sqrt(252)  # 252 trading days
    
    return min(annual_vol, 2.0)  # Cap at 200%

def calculate_black_scholes_estimate(S, K, T, r, sigma, option_type='call'):
    """Simple Black-Scholes estimate (rough approximation)"""
    if T <= 0 or sigma <= 0:
        return 0
    
    try:
        from math import log, sqrt, exp
        from scipy.stats import norm
        
        d1 = (log(S/K) + (r + sigma**2/2) * T) / (sigma * sqrt(T))
        d2 = d1 - sigma * sqrt(T)
        
        if option_type.lower() == 'call':
            price = S * norm.cdf(d1) - K * exp(-r * T) * norm.cdf(d2)
        else:
            price = K * exp(-r * T) * norm.cdf(-d2) - S * norm.cdf(-d1)
        
        return max(price, 0)
    except ImportError:
        # Fallback: simple intrinsic value + time value estimate
        intrinsic = max(0, S - K) if option_type.lower() == 'call' else max(0, K - S)
        time_value = sigma * sqrt(T) * S * 0.4  # Rough approximation
        return intrinsic + time_value
    except:
        return 0

def create_synthetic_option_contract(symbol, stock_price, bars, option_type='call'):
    """Create a synthetic option contract when real data isn't available"""
    # Choose ATM strike
    strike = round(stock_price / 5) * 5  # Round to nearest $5
    
    # Use next Friday as expiration (common for weekly options)
    today = datetime.date.today()
    days_until_friday = (4 - today.weekday()) % 7
    if days_until_friday == 0:  # If today is Friday, use next Friday
        days_until_friday = 7
    
    expiry = today + datetime.timedelta(days=days_until_friday)
    expiry_str = expiry.strftime('%Y-%m-%d')
    dte = (expiry - today).days
    
    # Time to expiration in years
    T = dte / 365.0
    
    # Estimate IV from historical volatility
    estimated_iv = calculate_implied_volatility_estimate(bars)
    
    # Risk-free rate (approximate)
    r = 0.05
    
    # Calculate estimated option price
    estimated_price = calculate_black_scholes_estimate(
        stock_price, strike, T, r, estimated_iv, option_type
    )
    
    # Create synthetic contract
    option_symbol = f"{symbol}{expiry.strftime('%y%m%d')}{'C' if option_type.lower() == 'call' else 'P'}{int(strike*1000):08d}"
    
    return {
        "symbol": option_symbol,
        "option_type": option_type.upper()[0],  # 'C' or 'P'
        "strike_price": strike,
        "expiration_date": expiry_str,
        "underlying_symbol": symbol,
        "dte": dte,
        "estimated": True,
        "delta": round(0.5 if abs(stock_price - strike) < 1 else (0.7 if stock_price > strike else 0.3), 2),
        "iv": round(estimated_iv * 100, 2)  # Convert to percentage
    }

def get_option_contract(symbol, stock_price, trade_style="scalp"):
    """
    This function is called by alert_engine.py
    Returns a suitable option contract for the given symbol and price
    """
    # For now, return a synthetic contract since options data might not be available
    # You can enhance this later to try real options data first
    
    # Choose call vs put based on trade style (simplified logic)
    option_type = 'call' if trade_style.lower() in ['scalp', 'day', 'swing'] else 'put'
    
    # Create a synthetic contract with minimal bars data (empty list fallback)
    contract = create_synthetic_option_contract(symbol, stock_price, [], option_type)
    
    return contract

async def generate_alert(symbol):
    print(f"🔄 Generating enhanced alert for {symbol}...")
    
    async with aiohttp.ClientSession() as session:
        # Get stock data
        stock_data = await fetch_stock_quote(symbol, session)
        if not stock_data:
            print(f"❌ Failed to fetch stock quote for {symbol}")
            return
        
        print(f"✅ Current price: ${stock_data.get('last_price', 'N/A')}")
        
        # Get historical data for volatility estimation
        bars = await fetch_stock_bars(symbol, session)
        print(f"📊 Retrieved {len(bars)} historical bars")
        
        # Try to get real options data
        contracts = await fetch_option_chain(symbol, session)
        
        current_price = stock_data.get("last_price", stock_data.get("ask_price", 0))
        
        if contracts:
            print(f"✅ Using real options data - {len(contracts)} contracts available")
            # Use real options data (your existing logic here)
            # Filter for near-the-money contracts
            filtered_contracts = [
                c for c in contracts 
                if c.get("strike_price") and abs(float(c["strike_price"]) - current_price) <= 10
            ]
            
            if filtered_contracts:
                best_contract = min(filtered_contracts, 
                                  key=lambda x: abs(float(x["strike_price"]) - current_price))
                print(f"📋 Selected contract: {best_contract.get('symbol', 'N/A')}")
                print(f"   Strike: ${best_contract.get('strike_price', 'N/A')}")
                print(f"   Expiry: {best_contract.get('expiration_date', 'N/A')}")
            else:
                print("⚠️ No suitable contracts found in real data")
        else:
            print("🔧 Using synthetic options estimation...")
            # Create synthetic call and put options
            synthetic_call = create_synthetic_option_contract(symbol, current_price, bars, 'call')
            synthetic_put = create_synthetic_option_contract(symbol, current_price, bars, 'put')
            
            print(f"📋 Synthetic Call Option:")
            print(f"   Symbol: {synthetic_call['symbol']}")
            print(f"   Strike: ${synthetic_call['strike_price']}")
            print(f"   Expiry: {synthetic_call['expiration_date']}")
            print(f"   Est. Delta: {synthetic_call['delta']}")
            
            print(f"📋 Synthetic Put Option:")
            print(f"   Symbol: {synthetic_put['symbol']}")
            print(f"   Strike: ${synthetic_put['strike_price']}")
            print(f"   Expiry: {synthetic_put['expiration_date']}")
            print(f"   Est. Delta: {synthetic_put['delta']}")
            
            print(f"\n💡 Recommendations based on synthetic analysis:")
            if synthetic_call['iv'] > 30:
                print(f"   📈 High implied volatility detected - consider selling options")
            else:
                print(f"   📉 Low implied volatility detected - consider buying options")
            
            if current_price > float(synthetic_call['strike_price']):
                print(f"   🎯 Stock is above strike - call option is ITM")
            else:
                print(f"   🎯 Stock is below strike - put option is ITM")

if __name__ == "__main__":
    if len(sys.argv) > 1:
        symbol = sys.argv[1].upper()
    else:
        symbol = "AAPL"
    
    asyncio.run(generate_alert(symbol))
