import requests
import json
import numpy as np
from datetime import datetime, timedelta
import pytz
from utils import get_secret
from data_feed import get_option_contract
from telegram_alert import send_telegram_alert
import time

def get_fallback_volatility_data(symbol: str, price: float) -> dict:
    """
    Use a free API as fallback for volatility estimation
    """
    try:
        # Try Alpha Vantage free tier (replace with your key if you have one)
        # This is just an example - you might need to register for a free key
        print(f"🔄 Trying fallback data source for {symbol}...")
        
        # For now, we'll use reasonable defaults based on common market conditions
        # You can enhance this by integrating with free APIs like Yahoo Finance
        
        # Market-based defaults (you can customize these)
        volatility_defaults = {
            'AAPL': 0.25,
            'GOOGL': 0.30,
            'MSFT': 0.28,
            'TSLA': 0.45,
            'SPY': 0.20,
            'QQQ': 0.25,
            'NVDA': 0.40,
            'META': 0.35,
            'AMZN': 0.32
        }
        
        # Get symbol-specific volatility or use default
        estimated_vol = volatility_defaults.get(symbol.upper(), 0.30)
        
        print(f"✅ Using estimated volatility: {estimated_vol*100:.1f}%")
        
        return {
            'volatility': estimated_vol,
            'source': 'estimated',
            'confidence': 'medium'
        }
        
    except Exception as e:
        print(f"⚠️ Fallback data also failed: {e}")
        return {
            'volatility': 0.25,  # 25% default
            'source': 'default',
            'confidence': 'low'
        }

def calculate_sl_tp_improved(price: float, symbol: str, style: str) -> dict:
    """
    Improved SL/TP calculation with multiple fallback methods
    """
    alpaca_key = get_secret("APCA_API_KEY_ID")
    alpaca_secret = get_secret("APCA_API_SECRET_KEY")
    headers = {
        "APCA-API-KEY-ID": alpaca_key,
        "APCA-API-SECRET-KEY": alpaca_secret
    }

    # Try different timeframes and endpoints
    endpoints_to_try = [
        {
            "url": f"https://data.alpaca.markets/v2/stocks/{symbol}/bars",
            "params": {
                "timeframe": "1Hour",
                "start": (datetime.utcnow() - timedelta(days=5)).isoformat() + "Z",
                "end": datetime.utcnow().isoformat() + "Z",
                "limit": 50,
                "feed": "iex"
            }
        },
        {
            "url": f"https://data.alpaca.markets/v2/stocks/{symbol}/bars",
            "params": {
                "timeframe": "1Day",
                "start": (datetime.utcnow() - timedelta(days=30)).isoformat() + "Z",
                "end": datetime.utcnow().isoformat() + "Z",
                "limit": 20,
                "feed": "iex"
            }
        }
    ]

    print(f"🔍 Attempting to fetch historical data for {symbol}...")
    
    bars = []
    for i, endpoint in enumerate(endpoints_to_try):
        print(f"   📡 Trying endpoint {i+1}...")
        try:
            response = requests.get(endpoint["url"], headers=headers, params=endpoint["params"], timeout=10)
            print(f"   📊 API Response Status: {response.status_code}")
            
            if response.status_code == 200:
                data = response.json()
                bars = data.get("bars", [])
                if bars:
                    print(f"   ✅ Retrieved {len(bars)} bars")
                    break
            elif response.status_code == 403:
                print(f"   ❌ Access forbidden - check API permissions or market data subscription")
            elif response.status_code == 429:
                print(f"   ❌ Rate limited - waiting 2 seconds...")
                time.sleep(2)
            else:
                print(f"   ❌ API Error: {response.status_code}")
                
        except requests.exceptions.Timeout:
            print(f"   ⏰ Request timeout for endpoint {i+1}")
        except Exception as e:
            print(f"   ❌ Request failed: {e}")

    # If we got historical data, use it
    if bars and len(bars) >= 2:
        print("✅ Using historical data for SL/TP calculation")
        closes = [bar["c"] for bar in bars if "c" in bar and bar["c"] > 0]
        
        if len(closes) >= 2:
            mean = np.mean(closes)
            std_dev = np.std(closes)
            
            # Style-based multipliers
            style_multipliers = {
                'scalp': {'sl': 0.8, 'tp': 1.2},
                'day': {'sl': 1.0, 'tp': 1.5},
                'swing': {'sl': 1.5, 'tp': 2.0}
            }
            
            multiplier = style_multipliers.get(style.lower(), {'sl': 1.0, 'tp': 1.5})
            
            sl = price - (std_dev * multiplier['sl'])
            tp = price + (std_dev * multiplier['tp'])
            
            # Cap take-profit for scalp trades at 2% above entry
            if style.lower() == 'scalp':
                tp = min(tp, price * 1.02)
            
            return {
                "stop_loss": round(max(sl, price * 0.95), 2),  # Cap SL at 5% loss
                "take_profit": round(tp, 2),
                "strategy": f"{style} strategy (historical volatility)",
                "confidence": "high",
                "data_points": len(closes)
            }

    # Fallback to estimated volatility
    print("⚠️ No historical data available - using fallback estimation")
    fallback_data = get_fallback_volatility_data(symbol, price)
    volatility = fallback_data['volatility']
    
    # Style-based parameters
    style_params = {
        'scalp': {'sl_pct': 1.0, 'tp_pct': 1.5, 'vol_mult': 0.5},
        'day': {'sl_pct': 1.5, 'tp_pct': 2.5, 'vol_mult': 0.8},
        'swing': {'sl_pct': 2.5, 'tp_pct': 4.0, 'vol_mult': 1.0}
    }
    
    params = style_params.get(style.lower(), style_params['day'])
    
    # Calculate based on estimated volatility
    vol_based_move = price * volatility * params['vol_mult']
    
    sl = price - max(vol_based_move, price * (params['sl_pct'] / 100))
    tp = price + max(vol_based_move * 1.5, price * (params['tp_pct'] / 100))
    
    # Cap take-profit for scalp trades at 2% above entry
    if style.lower() == 'scalp':
        tp = min(tp, price * 1.02)

    return {
        "stop_loss": round(max(sl, price * 0.97), 2),  # Never risk more than 3%
        "take_profit": round(tp, 2),
        "strategy": f"{style} strategy (estimated volatility: {volatility*100:.1f}%)",
        "confidence": fallback_data['confidence'],
        "source": fallback_data['source']
    }

def validate_api_access():
    """
    Check API access and permissions
    """
    print("🔍 Validating API access...")
    
    alpaca_key = get_secret("APCA_API_KEY_ID")
    alpaca_secret = get_secret("APCA_API_SECRET_KEY")
    
    if not alpaca_key or not alpaca_secret:
        print("❌ Missing API credentials")
        return False
    
    headers = {
        "APCA-API-KEY-ID": alpaca_key,
        "APCA-API-SECRET-KEY": alpaca_secret
    }
    
    # Test account access
    try:
        account_url = "https://paper-api.alpaca.markets/v2/account"
        response = requests.get(account_url, headers=headers, timeout=10)
        
        if response.status_code == 200:
            account_data = response.json()
            print(f"✅ Account access confirmed")
            print(f"   Account Status: {account_data.get('status', 'unknown')}")
            return True
        else:
            print(f"❌ Account access failed: {response.status_code}")
            return False
            
    except Exception as e:
        print(f"❌ API validation error: {e}")
        return False

def generate_alert_improved(symbol: str, trade_style: str = "scalp", account_size: float = 10000, risk_percent: float = 2.0):
    """
    Improved alert generation with better error handling
    """
    print("=" * 60)
    print(f"🔄 Generating alert for {symbol.upper()}...")
    print(f"📊 Trade Style: {trade_style.capitalize()}")
    print(f"💰 Account Size: ${account_size:,.2f}")
    print(f"⚠️ Risk per Trade: {risk_percent}%")
    print("=" * 60)

    # Validate API access first
    if not validate_api_access():
        print("❌ API access validation failed - continuing with limited functionality")

    alpaca_key = get_secret("APCA_API_KEY_ID")
    alpaca_secret = get_secret("APCA_API_SECRET_KEY")
    headers = {
        "APCA-API-KEY-ID": alpaca_key,
        "APCA-API-SECRET-KEY": alpaca_secret
    }

    # Get latest price with retry logic
    current_price = None
    quote_attempts = 0
    max_quote_attempts = 3
    
    while quote_attempts < max_quote_attempts and not current_price:
        quote_attempts += 1
        print(f"🔍 Fetching current quote for {symbol.upper()} (attempt {quote_attempts})...")
        
        try:
            quote_url = f"https://data.alpaca.markets/v2/stocks/{symbol}/quotes/latest"
            quote_response = requests.get(quote_url, headers=headers, params={"feed": "iex"}, timeout=10)
            
            print(f"   📡 Quote API Status: {quote_response.status_code}")
            
            if quote_response.status_code == 200:
                quote_data = quote_response.json().get("quote", {})
                ask = quote_data.get("ap", 0)
                bid = quote_data.get("bp", 0)
                
                if ask and bid:
                    current_price = round((ask + bid) / 2, 2)
                    print(f"✅ Current price: ${current_price} (spread: ${abs(ask-bid):.2f})")
                else:
                    print("⚠️ No ask/bid in quote - trying alternative approach")
                    
            elif quote_response.status_code == 403:
                print("❌ Quote access forbidden - using fallback pricing")
                break
            else:
                print(f"❌ Quote fetch failed with status {quote_response.status_code}")
                
        except requests.exceptions.Timeout:
            print(f"   ⏰ Quote request timeout (attempt {quote_attempts})")
        except Exception as e:
            print(f"   ❌ Quote request error: {e}")
        
        if quote_attempts < max_quote_attempts and not current_price:
            print("   🔄 Retrying in 2 seconds...")
            time.sleep(2)

    # Fallback pricing if quotes failed
    if not current_price:
        print("⚠️ Using estimated pricing - results may be less accurate")
        # You could integrate with a free API here or use last known prices
        estimated_prices = {
            'AAPL': 210.00, 'GOOGL': 2800.00, 'MSFT': 420.00, 'TSLA': 250.00,
            'SPY': 540.00, 'QQQ': 460.00, 'NVDA': 900.00, 'META': 500.00
        }
        current_price = estimated_prices.get(symbol.upper(), 100.00)
        print(f"📊 Using estimated price: ${current_price}")

    # Calculate SL/TP with improved method
    sl_tp = calculate_sl_tp_improved(current_price, symbol, trade_style)
    
    if not sl_tp.get("stop_loss") or not sl_tp.get("take_profit"):
        print("❌ Critical error: Could not calculate stop loss or take profit")
        return

    stop_loss = sl_tp["stop_loss"]
    take_profit = sl_tp["take_profit"]
    strategy_used = sl_tp["strategy"]
    confidence = sl_tp.get("confidence", "unknown")

    # Position sizing calculations
    risk_per_trade = round(account_size * (risk_percent / 100), 2)
    risk_per_share = round(current_price - stop_loss, 2)
    
    if risk_per_share <= 0:
        print("❌ Invalid risk calculation - stop loss above entry price")
        return
        
    shares = max(1, int(risk_per_trade / risk_per_share))
    reward = round(take_profit - current_price, 2)
    rr_ratio = round(reward / risk_per_share, 2) if risk_per_share > 0 else 0
    
    # Cap R:R ratio at 3 for scalp trades
    if style.lower() == 'scalp' and rr_ratio > 3:
        rr_ratio = 3.0
        take_profit = current_price + (risk_per_share * 3)
        reward = round(take_profit - current_price, 2)

    # Get option contract (using existing function)
    print("🔍 Fetching option contract...")
    try:
        contract = get_option_contract(symbol, current_price, trade_style)
        if contract:
            print(f"✅ Option contract: {contract.get('symbol', 'N/A')}")
        else:
            print("⚠️ Could not generate option contract")
            contract = {
                'symbol': f"{symbol}_OPTION",
                'strike_price': round(current_price),
                'expiration_date': (datetime.now() + timedelta(days=7)).strftime('%Y-%m-%d'),
                'delta': 0.5,
                'iv': 0.25,
                'option_type': 'CALL',
                'dte': 7
            }
    except Exception as e:
        print(f"❌ Option contract error: {e}")
        contract = {
            'symbol': f"{symbol}_OPTION",
            'strike_price': round(current_price),
            'expiration_date': (datetime.now() + timedelta(days=7)).strftime('%Y-%m-%d'),
            'delta': 0.5,
            'iv': 0.25,
            'option_type': 'CALL',
            'dte': 7
        }

    # Prepare alert data
    alert_data = {
        "symbol": symbol.upper(),
        "alert_type": f"AUTO-{trade_style.upper()}",
        "trade_type": trade_style.capitalize(),
        "price": current_price,
        "stop_loss": stop_loss,
        "take_profit": take_profit,
        "strike": contract.get("strike_price", current_price),
        "dte": contract.get("dte", 7),
        "delta": contract.get("delta", 0.5),
        "iv": contract.get("iv", 25) if isinstance(contract.get("iv"), (int, float)) else 25,
        "option_price": contract.get("option_price", 0.0),
        "timestamp": datetime.now().strftime("%Y-%m-%d %I:%M %p"),
        "confidence": confidence
    }

    # Display comprehensive alert
    print("\n" + "=" * 50)
    print("✅ TRADING ALERT GENERATED")
    print("=" * 50)
    print(f"📊 Symbol: {symbol.upper()}")
    print(f"🎯 Alert Type: AUTO-{trade_style.upper()}")
    print(f"💰 Trade Style: {trade_style.capitalize()}")
    print(f"🎖️ Confidence: {confidence.upper()}")
    print()
    print(f"📈 ENTRY DETAILS:")
    print(f"• Price:      ${current_price}")
    print(f"• Stop Loss:  ${stop_loss} (Risk: ${risk_per_share}/share)")
    print(f"• Take Profit: ${take_profit} (Reward: ${reward}/share)")
    print(f"• R:R Ratio:  1:{rr_ratio}")
    print(f"• Strategy:   {strategy_used}")
    print()
    print(f"💵 POSITION SIZING:")
    print(f"• Shares:     {shares:,} shares")
    print(f"• Position:   ${shares * current_price:,.2f}")
    print(f"• Max Risk:   ${risk_per_trade:,.2f} ({risk_percent}% of account)")
    print(f"• Max Reward: ${reward * shares:,.2f}")
    print(f"• Account:    ${account_size:,.2f}")
    print()
    print(f"📋 OPTION INFO:")
    print(f"• Contract:   {contract.get('symbol', 'N/A')}")
    print(f"• Strike:     ${contract.get('strike_price', 'N/A')}")
    print(f"• Expiry:     {contract.get('expiration_date', 'N/A')}")
    print(f"• DTE:        {contract.get('dte', 'N/A')} days")
    print(f"• Delta:      {contract.get('delta', 'N/A')}")
    print(f"• IV:         {contract.get('iv', 'N/A')}%")
    print(f"• Type:       {contract.get('option_type', 'N/A')}")
    print()
    print(f"🕒 Generated: {datetime.now(pytz.timezone('US/Eastern')).strftime('%I:%M %p EST')}")
    print(f"🗓️ Date: {datetime.now().date()}")
    print("=" * 50)

    # Risk management recommendations
    print(f"\n💡 RECOMMENDATIONS:")
    if confidence == 'high':
        print("   ✅ High confidence - proceed with trade")
    elif confidence == 'medium':
        print("   ⚠️ Medium confidence - consider reducing position size")
    else:
        print("   🚨 Low confidence - trade with extreme caution")
    
    if rr_ratio >= 2:
        print("   🎯 Excellent risk/reward ratio")
    elif rr_ratio >= 1.5:
        print("   👍 Good risk/reward ratio")
    else:
        print("   ⚠️ Consider adjusting targets for better R:R")

    # Send to Telegram
    try:
        print(f"\n📱 Sending alert to Telegram...")
        if send_telegram_alert(alert_data):
            print("✅ Telegram alert sent successfully!")
        else:
            print("❌ Failed to send Telegram alert")
    except Exception as e:
        print(f"❌ Telegram error: {e}")

    return alert_data

if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("🚀 Enhanced Trading Alert Generator")
        print("⚡ Usage: python3 alert_engine.py [SYMBOL] [STYLE] [ACCOUNT_SIZE] [RISK_%]")
        print("📝 Example: python3 alert_engine.py AAPL scalp 25000 1.5")
        print("\n📊 Available styles: scalp, day, swing")
        print("💡 The system will automatically handle API limitations and provide fallbacks")
        sys.exit()

    symbol = sys.argv[1].upper()
    style = sys.argv[2] if len(sys.argv) > 2 else "scalp"
    account = float(sys.argv[3]) if len(sys.argv) > 3 else 10000
    risk = float(sys.argv[4]) if len(sys.argv) > 4 else 2.0

    generate_alert_improved(symbol, style, account, risk)
