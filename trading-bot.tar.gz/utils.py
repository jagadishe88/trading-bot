import json

def get_secret(key: str) -> str:
    with open("secrets.json") as f:
        secrets = json.load(f)
    return secrets.get(key)

