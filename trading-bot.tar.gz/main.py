import asyncio
from concurrent.futures import ThreadPoolExecutor
from data_feed import fetch_live_data
from strategy_logic import evaluate_bundled_alert
from telegram_alert import send_telegram_alert

# List of symbols to monitor
symbols = [
    "SPX", "QQQ", "SPY", "IWM", "PG", "PEP", "AAPL", "MSFT", "NVDA", "TSLA",
    "META", "AMZN", "GOOGL", "NFLX", "LLY", "COIN", "MSTR", "AMD", "AVGO", "ARM",
    "CRWD", "PANW", "CRM", "BA", "COST", "HD", "ADBE", "SNOW", "LULU", "UNH",
    "CAT", "ANF", "DELL", "DE", "MDB", "GLD", "PDD", "ORCL", "TGT", "FDX",
    "AXP", "CMG", "NKE", "BABA", "WMT", "ROKU", "HIMS", "OSCR", "CRCL"
]

print("🚀 Starting Async Trading Bot...\n")

executor = ThreadPoolExecutor(max_workers=10)  # Tune this as needed

async def process_symbol(symbol):
    print(f"📡 Checking {symbol}...")
    try:
        # Run fetch_live_data in a thread to avoid blocking
        loop = asyncio.get_event_loop()
        data = await loop.run_in_executor(executor, fetch_live_data, symbol)

        if not data or data.get("current_price", 0) == 0:
            print(f"⚠️ No valid price data for {symbol}")
            return

        data["price"] = data["current_price"]
        data["symbol"] = symbol

        alert = evaluate_bundled_alert(data)
        if alert:
            send_telegram_alert(alert)
            print(f"✅ Alert sent: {alert['symbol']} - {alert['alert_type']}")
        else:
            print(f"⚠️ No valid alert for {symbol}")

    except Exception as e:
        print(f"❌ Error processing {symbol}: {e}")

async def main():
    await asyncio.gather(*(process_symbol(sym) for sym in symbols))

if __name__ == "__main__":
    asyncio.run(main())

